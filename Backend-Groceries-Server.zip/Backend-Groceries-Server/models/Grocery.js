const mongoose = require("mongoose");

const grocerySchema = new mongoose.Schema({
  name: {
    type: String
  },
  quantity: {
    type: Number
  },
  done: {
    type: Boolean
  }
});

module.exports = mongoose.model("Grocery", grocerySchema);