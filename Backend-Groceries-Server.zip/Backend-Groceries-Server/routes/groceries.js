const express = require("express");
const router = express.Router();
const Grocery = require("../models/Grocery");

// Get all grocery items
router.get("/", async (req, res) => {
  try {
    console.log("Listing groceries items...");
    //const groceries = await Grocery.find();
    const groceries = await getAllGroceryItems();
    res.json(groceries);
  }
  catch(err){
    res.status(500).json({message: err.message})
  }
});

// Getting a single grocery item
router.get("/:id", getGroceryItem, (req, res) => {
  res.json(res.groceryItem);
});

// Create a grocery Item
router.post("/", async (req, res) => {

  console.log("Creating grocery item...");

  const grocery = new Grocery({
    name: req.body.name,
    quantity: req.body.quantity,
    done: false
  });

  try {
    await grocery.save();
    res.status(201).json(await getAllGroceryItems());
  }
  catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Update a grocery Item
router.put("/:id", getGroceryItem, async (req, res) => {

  res.groceryItem.name = req.body.name;
  res.groceryItem.quantity = req.body.quantity;

  try {
    await res.groceryItem.save();
    res.json(await getAllGroceryItems());
  }
  catch(err) {
    res.status(400).json({ message: err.message });
  }
});

// De;ete a grocery item
router.delete("/:id", getGroceryItem, async (req, res) => {
  try {
    await res.groceryItem.deleteOne();
    res.json(await getAllGroceryItems());
  }
  catch(err) {
    res.status(500).json({ message: err.message });
  }
});

const getAllGroceryItems = async () => {
  return await Grocery.find();
}

async function getGroceryItem(req, res, next) {
  let groceryItem;

  try {
    groceryItem = await Grocery.findById(req.params.id);
    if (groceryItem === null){
      return res.status(404).json({ message: "Cannot find grocery item"})
    }
  }
  catch (err){
    res.status(500).json({ message: err.message});
  }

  res.groceryItem = groceryItem;
  next();
}

module.exports = router; 